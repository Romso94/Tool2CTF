import sys
from urllib.parse import urlparse
from tabulate import tabulate
import requests

WP_Ju1cy_3ndp01nts = [
    "wp-admin.php",
    "wp-config.php",
    "wp-content/uploads/",
    "wp-content/themes/",
    "wp-content/plugins/",
    "wp-admin",
    "wp-load",
    "wp-signup.php",
    "wp-json",
    "wp-includes",
    "index.php",
    "wp-login.php",
    "wp-links-opml.php",
    "wp-activate.php",
    "wp-cron.php",
    "wp-links.php",
    "wp-mail.php",
    "xmlrpc.php",
    "wp-settings.php",
    "wp-trackback.php",
    "admin-bar.php",
    "wp-blog-header.php",
    "wp-json/wp/v2/users"
]

def H4X0R(L1ST3, URL, F1L3=None):
    T3ST3D = []

    if F1L3:
        try:
            with open(F1L3, 'r') as file:
                L1ST3.extend(line.strip() for line in file)
        except FileNotFoundError:
            sys.exit(f"3rr0r : F1l3 n0t f0und - {F1L3}")

    for _3L3M3NT5 in L1ST3:
        full_url = f"{URL}/{_3L3M3NT5}"
        try:
            response = requests.get(full_url)
            T3ST3D.append([full_url, response.status_code])
        except requests.RequestException as e:
            T3ST3D.append([full_url, str(e)])
    
    print(tabulate(T3ST3D, headers=["URL", "R3SP0NS3"], tablefmt="rounded_grid"))

def H3LP():
    help_text = """
    Usage: WP_JU1CY_SC4NN3R.py [options]

    Options:
    -h, --help, h, help      Show this help message and exit
    -u URL, -U URL           Specify the base URL to scan
    -f FILE, -F FILE         Specify a TXT file containing additional endpoints to scan

    Example:
    python WP_JU1CY_SC4NN3R.py -u http://example.com -f endpoints.txt
    """

    print(help_text)

def format_url(url):
    parsed_url = urlparse(url)
    if not parsed_url.scheme:
        url = "http://" + url
    return url

if __name__ == "__main__":
    C0mm4nd3 = sys.argv
    URL, P4TH_TO_F1L3 = None, None
    
    if len(sys.argv) < 2 or sys.argv[1] in ["-h", "--help", "h", "help"]:
        H3LP()
        sys.exit(0)

    if "-u" in C0mm4nd3 or "-U" in C0mm4nd3:
        Ind3x = C0mm4nd3.index("-u") + 1 if "-u" in C0mm4nd3 else C0mm4nd3.index("-U") + 1
        if Ind3x < len(C0mm4nd3):
            URL = format_url(C0mm4nd3[Ind3x])
        else:
            sys.exit("3rr0r : N0 url f0und 4ft3r 0pt10n '-u'")

    if "-f" in C0mm4nd3 or "-F" in C0mm4nd3:
        Ind3x = C0mm4nd3.index("-f") + 1 if "-f" in C0mm4nd3 else C0mm4nd3.index("-F") + 1
        if Ind3x < len(C0mm4nd3):
            P4TH_TO_F1L3 = C0mm4nd3[Ind3x]
        else:
            sys.exit("3rr0r : N0 p4th t0 f1l3 f0und 4ft3r '-f'")

    H4X0R(WP_Ju1cy_3ndp01nts, URL, P4TH_TO_F1L3)



    
    
    